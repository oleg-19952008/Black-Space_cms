<?php header("Content-type: text/xml"); ?>
<catalog>
<achievements>
<item id="2" price="0.9900" currency="EUR" />
<item id="4" price="0.9900" currency="EUR" />
<item id="6" price="0.9900" currency="EUR" />
<item id="7" price="0.9900" currency="EUR" />
<item id="9" price="0.9900" currency="EUR" />
<item id="10" price="0.9900" currency="EUR" />
<item id="11" price="0.9900" currency="EUR" />
<item id="12" price="0.9900" currency="EUR" />
</achievements>
<specialOffer>
<item id="1" price="0.9900" currency="EUR" />
<item id="2" price="4.9900" currency="EUR" />
<item id="3" price="4.9900" currency="EUR" />
<item id="4" price="0.9900" currency="EUR" />
<item id="7" price="0.9900" currency="EUR" />
<item id="8" price="0.9900" currency="EUR" />
<item id="5" price="0.9900" currency="EUR" />
<item id="6" price="25.0000" currency="EUR" />
</specialOffer>
</catalog>
