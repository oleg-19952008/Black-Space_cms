<?php header("Content-type: text/xml"); ?> 
<resource>
<item id="label_start"><![CDATA[Вперед]]></item>
<item id="label_home"><![CDATA[Главная]]></item>
<item id="link_home"><![CDATA[http://25.140.223.97/internalDock]]></item>
<item id="label_hangar"><![CDATA[Ангар]]></item>
<item id="label_trade"><![CDATA[Магазин]]></item>
<item id="label_skylab"><![CDATA[Скайлеб]]></item>
<item id="label_clan"><![CDATA[Клан]]></item>
<item id="label_money"><![CDATA[Услуги за реал]]></item>
<item id="label_quests"><![CDATA[Задания]]></item>
<item id="label_help"><![CDATA[Помощь]]></item>
<item id="label_logout"><![CDATA[Выход]]></item>
<item id="label_support"><![CDATA[Поддержка]]></item>
<item id="label_userdata"><![CDATA[ID: Опыт: Уровень:]]></item>
<item id="label_misc"><![CDATA[Джекпот: Кредиты: Уридиум:]]></item>
<item id="label_users"><![CDATA[Игроки онлайн]]></item>
<item id="label_galaxy_gates"><![CDATA[GALAXY GATES]]></item>
<item id="label_skilltree"><![CDATA[ÁRBOL HABILIDADES]]></item>
<item id="label_pilotsheet"><![CDATA[PILOT SHEET]]></item>
</resource>