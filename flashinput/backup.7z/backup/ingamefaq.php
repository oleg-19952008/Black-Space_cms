<?xml version='1.0' encoding='utf-8'?>
<faq>
<main>
Old DarkOrbit Remix PS - developed by Manulaiko - published by DarkOrbit Remix DevTeam

1. License.
2. Credits.
3. Thanks.

1. License:

	Old DarkOrbit Remix PS is a free browser game based in 2008 DarkOrbit (thanks to Snowy's files).

	While playing to Old DarkOrbit Remix PS or DarkOrbit Remix PS or even visiting our forum you agree with these terms:

		1. The User isn't allowed to use bugs, exploits, cheats, hacks or any other thing dangerous for Old DarkOrbit Remix PS/DarkOrbit Remix PS.
		2. If the user find a bug he must report it to any member of DarkOrbit Remix DevTeam (Manulaiko, Predator, IGgnOx, Bla365 or Rider735).
		3. DarkOrbit Remix DevTeam reserve the right to close the server or reset accounts at any time.
		4. We don't make responsable of hacked accounts or password lost.
		5. If the User is UG LvL 1 he can't publish anything of the UG LvL 1 forum in other forums.
		6. If the User is UG LvL 2 he can't publish anything of the UG LvL 2 forum in other forums or UG LvL 1.
		7. If the User is UG LvL 3 he can't publish anything of the UG LvL 3 forum in other forums or UG LvL 1 & UG LvL 2.
		8. DarkOrbit remix DevTeams reserve the right to delete accounts if it's necessary.

2. Credits:

	Old DarkOrbit Remix PS:
		Developed by Manulaiko.
		Web design by Elieaz & Manulaiko.
		SpaceMap by Snowy & Manulaiko.
		Published by DarkOrbit Remix DevTeam.
		
	DarkOrbit Remix PS:
		Developed by Manulaiko, based on Azure server 5.1
		Web design by Manulaiko.
		
3. Thanks:

	This game wouldn't be possible without Elieaz & Xdr work.
	Thanks to -jD for his help in some problems I had while coding.
	Thanks to Cinnar for his help with the web design.
	Thanks to Snowy for the Spacemap files.
	Thanks to Predator, bla & Iggnox for be my bitches.
	Thanks to Pescho0 for... idk, but thanks Gay King.
	Thanks to Requi for his help while I was starting coding the emulator.
	Thanks to LolMan for the source of his emulator, I didn't  used it but I wanted to say thanks.
	Thanks to the ePvPers comunnity for be really kind with me :D
	
	And special thanks for your support.
	
	Hope you get fun in DarkOrbit Remix's Universe.
	
	See you!! (Manulaiko),

</main>
</faq>