<?php header("Content-type: text/xml"); ?>
<quests>
    <quest questCaseID="37"><![CDATA[Persigue a tus enemigos]]></quest>
	<quest questCaseID="641"><![CDATA[�200!]]></quest>
</quests>
